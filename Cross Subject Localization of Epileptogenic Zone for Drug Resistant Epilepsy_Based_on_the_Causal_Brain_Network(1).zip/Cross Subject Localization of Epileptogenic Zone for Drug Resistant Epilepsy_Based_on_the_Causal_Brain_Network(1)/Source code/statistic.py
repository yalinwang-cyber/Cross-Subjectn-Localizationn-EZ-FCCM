import numpy as np
import pandas as pd
import os
from os import path, listdir
from scipy.spatial.distance import pdist, squareform
from scipy.stats._stats_py import _unequal_var_ttest_denom
from sklearn import preprocessing
np.random.seed(42)

# List of unified features to analyze (including channel inward/outward means, extremes, stds, etc.)
COMMON_FEATURES = [
    'channel_means_outward', 'channel_means_inward', 'channel_min_outward', 'channel_max_outward',
    'channel_min_inward', 'channel_max_inward', 'channel_outward_std', 'channel_inward_std'
]

# Input data directory and output results directory
ROOT_DIR = r"statistics"
EXCEL_DIR = r"statistics_result"
os.makedirs(EXCEL_DIR, exist_ok=True)

# Significance level thresholds
ALPHA = 0.05
ALPHA_01 = 0.01
ALPHA_001 = 0.001
N_PERMUTATIONS = 10000  # Number of permutations for PERMANOVA test

# Normalize the input matrix using Z-score
def normalize_matrix(matrix, by="column"):
    if by in ["row", "r", 0]:
        # Transpose, apply sklearn scale, then transpose back
        result = preprocessing.scale(matrix.T)
        result = result.T
        return result
    raise ValueError(f"Invalid value for {by}")

# Compute the sample-to-sample distance matrix from the feature matrix
def convert_to_distance_matrix(matrix, metric="euclidean", norm="row", by="column"):
    input_matrix = matrix.copy()
    if norm in ["row", "r", 0, "rows"]:
        input_values = normalize_matrix(input_matrix, "row")
    elif norm in ["column", "col", 1, "c", "columns"]:
        input_values = normalize_matrix(input_matrix, "column")
    else:
        input_values = input_matrix.values
    # Transpose matrix if calculating column-wise
    if by in ["column", "col", "c", 1]:
        input_matrix = input_matrix.T
        input_values = input_values.T
    # Compute pairwise distance vector and convert to square matrix
    vector = pdist(input_values, metric=metric)
    dis_matrix = squareform(vector)
    dis_df = pd.DataFrame(dis_matrix, columns=input_matrix.index, index=input_matrix.index)
    return dis_df

# Calculate the denominator degrees of freedom for unequal variance t-test, used for subsequent effect size calculation
def calculate_degrees_freedom(matrix, item):
    first_matrix = matrix.loc[item[0]][item[0]]
    second_matrix = matrix.loc[item[1]][item[1]]
    var_x = sum_square_dist(first_matrix)
    var_y = sum_square_dist(second_matrix)
    n_x = len(first_matrix)
    n_y = len(second_matrix)
    dof = _unequal_var_ttest_denom(var_x, n_x, var_y, n_y)[0]
    return dof

#  Calculate Cohen's d effect size based on the F statistic and degrees of freedom
def Cohend(F, dof):
    cohend = 2 * (F / dof) ** 0.5
    return cohend

# Calculate the average squared distance of all elements in the distance matrix
def sum_square_dist(distance_matrix):
    return distance_matrix.values.sum() / len(distance_matrix)

# Compute the pseudo-F statistic
def F_stat(grouping, valid_distance):
    permuted_dismatrix = valid_distance.copy()
    permuted_dismatrix.columns = grouping
    permuted_dismatrix.index = grouping
    all_groups = list(set(grouping))
    # Total Sum of Squares (SST)
    SST = sum_square_dist(permuted_dismatrix)
    # Within-group Sum of Squares (SSW)
    SSW = 0
    for group in all_groups:
        sub_slice = permuted_dismatrix.loc[group][group]
        SSW = SSW + sum_square_dist(sub_slice)
    N = len(permuted_dismatrix)
    a = len(all_groups)
    SSA = SST - SSW  # Between-group Sum of Squares (SSA)
    # Compute pseudo-F value
    F = (SSA / (a - 1)) / (SSW / (N - a))
    return F

# Perform PERMANOVA test
def PERMANOVA(valid_distance, grouping=None, permutations=9999):
    if grouping is None:
        grouping = valid_distance.columns
    np.random.seed(42)
    # Compute F statistic for original data
    score = F_stat(grouping=grouping, valid_distance=valid_distance)
    # Construct permutation matrix by randomly shuffling grouping labels
    perm_df = pd.DataFrame(index=range(permutations), columns=range(len(grouping)))
    perm_df = perm_df.apply(
        lambda series, grouping: np.random.permutation(grouping),
        axis=1, result_type="expand", grouping=grouping
    )
    # Compute F statistic distribution across permutations
    outcomes = perm_df.apply(F_stat, axis=1, valid_distance=valid_distance)
    # Calculate permutation p-value
    pvalue = ((outcomes >= score).sum() + 1) / (permutations + 1)
    return pvalue, score

# Permutational analysis controller: integrates distance computation, PERMANOVA test, and effect size calculation
def permutational_analysis(data, mapping, column=None, **kwargs):
    input_matrix = data.copy()
    is_distance = kwargs.pop("dist", False)
    by = kwargs.pop("by", "column")
    norm = kwargs.pop("norm", "row")
    metric = kwargs.pop("metric", "euclidean")
    permutations = kwargs.pop("permutations", 9999)

    if by in ["column", 1, "col", "c"]:
        by = "column"
    elif by in ["row", "r", 0]:
        by = "row"
    sample_group_mapping = mapping
    if by == "column":
        input_matrix.columns = input_matrix.columns.map(sample_group_mapping)
    if by == "row":
        input_matrix.index = input_matrix.index.map(sample_group_mapping)
    if not is_distance:
        distance_matrix = convert_to_distance_matrix(input_matrix, metric=metric, norm=norm, by=by)
    else:
        distance_matrix = input_matrix.copy()
    distance_matrix = distance_matrix * distance_matrix

    # Run PERMANOVA
    pvalue, F = PERMANOVA(distance_matrix, permutations=permutations)

    # Calculate degrees of freedom and effect size (Cohen's d)
    dof = calculate_degrees_freedom(distance_matrix, ['EZ', 'NEZ'])
    cohend = Cohend(F, dof)
    return pvalue, F, cohend

# Extract all patient IDs from a given period folder (ictal / interictal)
def discover_patients(period):
    patients = []
    period_path = path.join(ROOT_DIR, period)
    if not path.exists(period_path):
        return patients
    for file in listdir(period_path):
        if not file.endswith('.xlsx') or file.startswith('~$'):
            continue
        parts = file.replace('.xlsx', '').split('_')
        if len(parts) < 5:
            continue
        pid = parts[0].upper()
        if pid not in patients:
            patients.append(pid)
    return sorted(patients)

# Load EZ and NEZ data for a single patient in a specific period
def load_patient_period_data(patient_id, period):
    ez, nez = [], []
    period_path = path.join(ROOT_DIR, period)
    if not path.exists(period_path):
        return np.array(ez), np.array(nez)
    for file in listdir(period_path):
        if not file.endswith('.xlsx') or file.startswith('~$'):
            continue
        parts = file.replace('.xlsx', '').split('_')
        if len(parts) < 5 or parts[0].upper() != patient_id.upper():
            continue
        rt = parts[-2].lower()
        try:
            df = pd.read_excel(path.join(period_path, file))
            df.columns = df.columns.str.strip().str.replace(' ', '_')
            for f in COMMON_FEATURES:
                if f'{rt}_{f}' in df.columns:
                    df[f] = df[f'{rt}_{f}'].fillna(df[f'{rt}_{f}'].mean())
                else:
                    df[f] = np.nan
            df = df[COMMON_FEATURES].fillna(df.mean()).dropna()

            if rt == 'ez':
                ez.extend(df.values)
            else:
                nez.extend(df.values)
        except:
            continue

    return np.array(ez), np.array(nez)

# Construct combined matrix for a single patient's EZ and NEZ data and execute PERMANOVA analysis
def run_permanova_analysis(ez_data, nez_data, n_permutations=5000):
    if ez_data.size == 0 or nez_data.size == 0:
        return np.nan, np.nan, np.nan
    if ez_data.shape[1] != nez_data.shape[1]:
        return np.nan, np.nan, np.nan
    n_ez, n_nez = len(ez_data), len(nez_data)
    # Skip analysis if sample size is too small
    if n_ez < 3 or n_nez < 3:
        return np.nan, np.nan, np.nan

    ez_df = pd.DataFrame(ez_data, columns=COMMON_FEATURES)
    nez_df = pd.DataFrame(nez_data, columns=COMMON_FEATURES)
    # Concatenate EZ and NEZ data
    combined_df = pd.concat([ez_df, nez_df], axis=0, ignore_index=True)
    group_labels = ['EZ'] * n_ez + ['NEZ'] * n_nez
    # Transpose to fit column-wise computation or sample mapping
    combined_df_T = combined_df.T
    combined_df_T.columns = [f'sample_{i}' for i in range(len(group_labels))]
    sample_mapping = dict(zip(combined_df_T.columns, group_labels))
    # Call core permutation analysis function
    p_val, f_stat, cohend = permutational_analysis(
        data=combined_df_T,
        mapping=sample_mapping,
        by='column',
        norm='row',
        metric='euclidean',
        permutations=n_permutations
    )
    return p_val, f_stat, cohend

# Perform batch statistical analysis for all patients within a specified period
def statistical_analysis(period):
    all_res = []
    patients = discover_patients(period)

    if not patients:
        print(f"[WARN] {period}: no patient files found under {path.join(ROOT_DIR, period)}")

    for pid in patients:
        # Load patient's EZ and NEZ data
        ez, nez = load_patient_period_data(pid, period)
        # Run PERMANOVA and effect size calculation
        permanova_p, f_stat, cohend = run_permanova_analysis(ez, nez, n_permutations=N_PERMUTATIONS)
        print(f"{pid} ({period}) → p={permanova_p:.5f} | F={f_stat:.2f} | Cohen's d={cohend:.3f}")
        # Record results and significance flags
        all_res.append({
            'Patient': pid,
            'Period': period,
            'p_value': permanova_p,
            'F_statistic': f_stat,
            'cohen_d': cohend,
            'significant_0.05': permanova_p < ALPHA if not np.isnan(permanova_p) else False,
            'significant_0.01': permanova_p < ALPHA_01 if not np.isnan(permanova_p) else False,
            'significant_0.001': permanova_p < ALPHA_001 if not np.isnan(permanova_p) else False
        })
    # Save results to an Excel file
    df_result = pd.DataFrame(all_res)
    df_result.to_excel(path.join(EXCEL_DIR, f'statistical_result_{period}.xlsx'), index=False)
    return df_result


if __name__ == "__main__":
    # Execute statistical analysis pipeline for both ictal and interictal periods
    df_ictal = statistical_analysis('ictal')
    df_interictal = statistical_analysis('interictal')