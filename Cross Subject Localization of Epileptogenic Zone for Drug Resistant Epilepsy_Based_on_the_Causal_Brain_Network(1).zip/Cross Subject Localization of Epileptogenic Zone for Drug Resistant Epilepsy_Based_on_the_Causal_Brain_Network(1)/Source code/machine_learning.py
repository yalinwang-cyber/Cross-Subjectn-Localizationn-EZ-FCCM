# SEEG epilepsy seizure zone binary classification, Leave-One-Patient-Out Cross Validation
# Distinguish EZ ictal channel(label=1) vs NEZ non-ictal channel(label=0) using SEEG features
# 3 data modes：
#   1. ictal: model using only ictal data
#   2. interictal: model using only interictal data
#   3. combined: concatenate ictal and interictal features for the same channel

import os, warnings
import pandas as pd
import numpy as np
from imblearn.over_sampling import SMOTE
from imblearn.under_sampling import RandomUnderSampler
from imblearn.combine import SMOTEENN
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.discriminant_analysis import LinearDiscriminantAnalysis
from sklearn.neural_network import MLPClassifier
from lightgbm import LGBMClassifier
from sklearn.metrics import precision_score, recall_score, accuracy_score, roc_auc_score, f1_score, confusion_matrix, \
    average_precision_score
warnings.filterwarnings("ignore")

ROOT = "statistics"          # Root dir of raw Excel features, contains ictal and interictal subfolders
OUTPUT_DIR = "machine_result"  # Output folder for model results, save summary Excel

# Scan and get all patient IDs
def get_patients():
    # Traverse ictal and interictal folders, parse filenames to extract patient IDs
    patients = set()
    # Iterate ictal and interictal subfolders
    for period in ['ictal', 'interictal']:
        period_path = os.path.join(ROOT, period)
        if not os.path.exists(period_path):
            continue
        for file in os.listdir(period_path):
            if file.endswith('.xlsx') and not file.startswith('~$'):
                # Remove .xlsx suffix, split filename by underscore
                parts = file.replace('.xlsx', '').split('_')
                if parts:
                    patients.add(parts[0].upper()) # Convert to uppercase to avoid case mismatch
    return sorted(list(patients))

# Detect available feature names
def get_features():
    # Read header of one excel file, extract features starting with EZ / NEZ
    for period in ['ictal', 'interictal']:
        path = os.path.join(ROOT, period)
        if not os.path.exists(path):
            continue
        for f in os.listdir(path):
            if f.endswith('.xlsx') and not f.startswith('~$'):
                fp = os.path.join(path, f)
                parts = f.replace('.xlsx', '').split('_')
                if len(parts) < 5:
                    continue
                rt = parts[-2].lower()
                cc = f"{rt}_channel"
                try:
                    df = pd.read_excel(fp, nrows=1)
                    df.columns = df.columns.str.strip().str.replace(' ', '_')
                    feats = [col[len(rt) + 1:] for col in df.columns if col.startswith(f"{rt}_") and col != cc]
                    if feats:
                        return feats
                except Exception:
                    continue
    return []

# Load dataset, support 3 modes
def load_data(mode, target_patients, feats):
    # 'ictal': load only ictal data
    # 'interictal': load only interictal data
    # 'combined': concat ictal & interictal features, inner join by Patient+Seizure+Channel+label
    # target_patients: patient ids included in analysis
    # feats: feature list to load
    # label definition: EZ seizure channel=1, NEZ non-seizure channel=0
    ictal, inter = [], []
    for period in ['ictal', 'interictal']:
        path = os.path.join(ROOT, period)
        if not os.path.exists(path):
            continue
        for f in os.listdir(path):
            if f.endswith('.xlsx') and not f.startswith('~$'):
                fp = os.path.join(path, f)
                parts = f.replace('.xlsx', '').split('_')
                if len(parts) < 5:
                    continue
                pid = parts[0].upper()
                if pid not in target_patients:
                    continue
                rt = parts[-2].lower()
                label, cc = (1 if rt == 'ez' else 0), f"{rt}_channel"
                try:
                    df = pd.read_excel(fp)
                    df.columns = df.columns.str.strip().str.replace(' ', '_')
                    if cc not in df.columns:
                        continue
                    df['Channel'] = df[cc].astype(str).str.strip()
                    for feat in feats:
                        oc = f"{rt}_{feat}"
                        df[feat] = df[oc] if oc in df.columns else np.nan
                    df['Patient'], df['Seizure'], df['label'] = pid, parts[1].lower(), label
                    df = df[feats + ['Patient', 'Seizure', 'label', 'Channel']]
                    (ictal if period == 'ictal' else inter).append(df)
                except Exception:
                    continue

    ictal_df = pd.concat(ictal, ignore_index=True) if ictal else pd.DataFrame()
    inter_df = pd.concat(inter, ignore_index=True) if inter else pd.DataFrame()

    if mode == 'ictal':
        return ictal_df
    elif mode == 'interictal':
        return inter_df
    else:
        if ictal_df.empty or inter_df.empty:
            return pd.DataFrame()
        # Add prefix to distinguish ictal_ and inter_ features
        ictal_df, inter_df = ictal_df.add_prefix('ictal_'), inter_df.add_prefix('inter_')
        for col in ['Patient', 'Seizure', 'Channel', 'label']:
            ictal_df[col], inter_df[col] = ictal_df[f'ictal_{col}'].astype(str), inter_df[f'inter_{col}'].astype(str)
        # Inner join: same patient, seizure, channel and label, merge ictal & interictal features
        return pd.merge(ictal_df, inter_df, on=['Patient', 'Seizure', 'Channel', 'label'], how='inner')

# Build feature matrix X, label y and patient id series
def prep_feat(df, mode, target_patients, feats):
    if df.empty:
        return pd.DataFrame(), pd.Series(), pd.Series()
    # Filter target patients
    df = df[df['Patient'].isin(target_patients)]
    # Select feature columns by mode
    if mode in ['ictal', 'interictal']:
        f_cols = feats
    else:
        # ccombined mode
        f_cols = [f'ictal_{f}' for f in feats] + [f'inter_{f}' for f in feats]
    df = df[f_cols + ['label', 'Patient']]
    return df[f_cols], df['label'].astype(int), df['Patient']

# Define 11 classifiers
def get_models():
    return {
        'SVM': SVC(probability=True, random_state=42, class_weight='balanced'),
        'XGBoost': XGBClassifier(random_state=42, eval_metric='logloss'),
        'RF': RandomForestClassifier(random_state=42, class_weight='balanced'),
        'LR': LogisticRegression(random_state=42, max_iter=1000), # 增大迭代次数保证收敛 / Increase max iteration for convergence
        'KNN': KNeighborsClassifier(),
        'DT': DecisionTreeClassifier(random_state=42),
        'NB': GaussianNB(),
        'AdaBoost': AdaBoostClassifier(random_state=42),
        'LDA': LinearDiscriminantAnalysis(),
        'MLP': MLPClassifier(max_iter=1000, random_state=42),
        'LGBM': LGBMClassifier(random_state=42)
    }

# Define 3 imbalance sampling methods
def get_samplers():
    # Over: SMOTE oversample; Under: random undersample; Mixed: SMOTEENN hybrid
    # Sampling only applied on training set, test set unchanged, prevent data leakage
    return {
        'Over': SMOTE(random_state=42),
        'Under': RandomUnderSampler(random_state=42),
        'Mixed': SMOTEENN(random_state=42)
    }

# Calculate classification metrics
def calc_metrics(y_true, y_pred, y_proba=None):
    # Input true label, predicted label, predicted probability, return metrics
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()  # Unpack confusion matrix
    acc, pre, sen = accuracy_score(y_true, y_pred), precision_score(y_true, y_pred, zero_division=0), recall_score(
        y_true, y_pred, zero_division=0)
    spe = tn / (tn + fp) if (tn + fp) > 0 else 0 # Specificity calculation
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc_val = roc_auc_score(y_true, y_proba) if (y_proba is not None and len(np.unique(y_true)) > 1) else 0.5  # AUC
    auprc_val = average_precision_score(y_true, y_proba) if (y_proba is not None) else 0.0  # AUPRC
    return {
        'Accuracy': round(acc, 4),
        'Precision': round(pre, 4),
        'Recall': round(sen, 4),
        'Specificity': round(spe, 4),
        'F1': round(f1, 4),
        'AUC': round(auc_val, 4),
        'AUPRC': round(auprc_val, 4)
    }

# Leave One Patient Out Cross Validation
def cv(X, y, pats, mode):
    #Pick one patient as test set, others as training set
    res, pats_unique, models, samplers = [], sorted(pats.unique()), get_models(), get_samplers()
    for fold, tp in enumerate(pats_unique, 1):
        print(f"Fold {fold}/{len(pats_unique)} | Test Patient: {tp}")
        tr_m, te_m = pats != tp, pats == tp
        X_tr, X_te, y_tr, y_te = X[tr_m].values, X[te_m].values, y[tr_m].values, y[te_m].values
        if len(np.unique(y_tr)) < 2:
            continue
        scaler = StandardScaler()
        X_tr_s = scaler.fit_transform(X_tr)
        X_te_s = scaler.transform(X_te)
        for m_name, model in models.items():
            for s_name, sampler in samplers.items():
                try:
                    X_res, y_res = sampler.fit_resample(X_tr_s, y_tr)  # Resample training data for class balance
                    model.fit(X_res, y_res)  # Fit model on resampled training data
                    y_proba = model.predict_proba(X_te_s)[:, 1]  # Get probability of positive class
                    best_th, best_f1 = 0.5, 0
                    for th in np.linspace(0.2, 0.7, 10):
                        f1 = f1_score(y_te, (y_proba >= th).astype(int), zero_division=0)
                        if f1 > best_f1: best_f1, best_th = f1, th
                    y_pred = (y_proba >= best_th).astype(int)
                    m = calc_metrics(y_te, y_pred, y_proba)
                    res.append({
                        'Model': m_name,
                        'Sampler': s_name,
                        'Test_Patient': tp,
                        **m,
                        'Best_Threshold': best_th
                    })
                except Exception as e:
                    continue
    return pd.DataFrame(res)

# Save results and compute mean±std summary
def save_and_analyze(results, mode):
    # results: fold-wise loocv results, mode: data mode
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)  # Create output folder
    if results.empty:
        print("No results.")
        return
    metric_cols = ['Precision', 'Recall', 'Specificity', 'Accuracy', 'AUC', 'F1', 'AUPRC']
    def mean_std_format(series):
        # Format string: mean ± std, 2 decimal places
        return f"{series.mean():.2f}±{series.std(ddof=0):.2f}"
    summary = results.groupby(['Sampler', 'Model'])[metric_cols].agg(mean_std_format).reset_index()
    summary_output = os.path.join(OUTPUT_DIR, f"Analysis_{mode}.xlsx")
    summary.to_excel(summary_output, index=False)
    print(f"Summary analysis saved to: {summary_output}\n")
    print(summary.to_string(index=False))


if __name__ == "__main__":
    mode = 'ictal'  # Options: ictal / interictal / combined
    target_patients = get_patients()  # Load all patient IDs
    feats = get_features()  # Detect feature list
    print(f"Detected Patients: {target_patients}")
    print(f"Detected Features: {feats}")
    df = load_data(mode, target_patients, feats)
    if not df.empty:
        X, y, pats = prep_feat(df, mode, target_patients, feats)  # Feature preprocessing
        cv_results = cv(X, y, pats, mode)  # Run LOOCV
        save_and_analyze(cv_results, mode)  # Save and summarize results
